class Dev:
    DEBUG = True
