from flask_manage_webpack import FlaskManageWebpack

manage_webpack = FlaskManageWebpack()
