### Install 
- `pip install -r requirements.txt`
- `cp .flaskenv.example .flaskenv`
- `npm start`
-  Visit http://localhost:5000