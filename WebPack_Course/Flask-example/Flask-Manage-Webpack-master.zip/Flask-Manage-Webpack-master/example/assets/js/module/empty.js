// This module is being used to detect if Dynamic import() is supported by the browser.
export default function empty() {}
